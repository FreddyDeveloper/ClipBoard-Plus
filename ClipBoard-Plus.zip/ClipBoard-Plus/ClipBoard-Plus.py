import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, 
    QListWidget, QListWidgetItem, QHBoxLayout, QMenu, QMessageBox, QFileDialog
)
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QTimer, Qt
import clipboard
from os.path import expanduser

class ClipboardManagerApp(QMainWindow):
    def __init__(self):
        super().__init__()

        self.init_ui()
        self.clipboard_history = []

    def init_ui(self):
        self.setWindowTitle("ClipBoard Plus v1.7 (by FreddyDeveloper)")
        self.setGeometry(100, 100, 600, 400)
        # self.setWindowIcon(QIcon("icon.ico"))

        layout = QVBoxLayout()

        self.list_widget = QListWidget()
        layout.addWidget(self.list_widget)

        self.save_button = QPushButton("SAVE (export the list of copied items to a txt file.)")
        self.save_button.clicked.connect(self.save_to_file)
        layout.addWidget(self.save_button)

        self.clear_button = QPushButton("DELETE (remove selected item, except the last copied.)")
        self.clear_button.clicked.connect(self.clear_selected)
        layout.addWidget(self.clear_button)

        central_widget = QWidget()
        central_layout = QHBoxLayout()

        central_layout.addLayout(layout)
        central_widget.setLayout(central_layout)

        self.setCentralWidget(central_widget)

        self.list_widget.itemClicked.connect(self.select_item)
        self.list_widget.setContextMenuPolicy(Qt.CustomContextMenu)
        self.list_widget.customContextMenuRequested.connect(self.show_context_menu)

        self.setStyleSheet("""
            QMainWindow {
                background-color: #F0F0F0;
            }
            QPushButton {
                background-color: #3498db;
                color: white;
                border: 2px solid #2980b9;
                border-radius: 8px;
                padding: 6px 12px;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
            QListWidget {
                background-color: white;
                border-radius: 8px;
                border: 2px solid #bdc3c7;
                padding: 10px;
                selection-background-color: #3498db;
                selection-color: white;
            }

            QListWidget::item {
                border-bottom: 1px solid #bdc3c7;
                color: black;
            }
        """)

    def update_clipboard_content(self):
        clipboard_text = clipboard.paste()
        if clipboard_text and clipboard_text not in self.clipboard_history:
            self.clipboard_history.append(clipboard_text)
            self.add_history_item(clipboard_text)

    def show_alert(self, message):
        alert = QMessageBox()
        alert.setIcon(QMessageBox.Information)
        alert.setText(message)
        alert.setStyleSheet("""
            background-color: white;
            border: 2px solid #3498db;
            border-radius: 8px;
            padding: 10px;
        """)
        alert.exec_()

    def clear_selected(self):
        selected_items = self.list_widget.selectedItems()
        
        if not selected_items:
            self.show_alert("No items selected to delete.")
            return
        
        for item in selected_items:
            self.remove_history_item(item)
            self.list_widget.takeItem(self.list_widget.row(item))

    def add_history_item(self, text):
        list_item = QListWidgetItem(text)
        list_item.setSizeHint(list_item.sizeHint())
        self.list_widget.addItem(list_item)
        self.update_list_item_style(list_item, False)

    def select_item(self, item):
        for index in range(self.list_widget.count()):
            current_item = self.list_widget.item(index)
            self.update_list_item_style(current_item, current_item == item)

    def copy_to_clipboard(self, item):
        clipboard_text = item.text()
        clipboard.copy(clipboard_text)
        self.show_alert("Copied selected item.")

    def show_context_menu(self, pos):
        selected_item = self.list_widget.itemAt(pos)
        if selected_item:
            menu = QMenu(self)
            copy_action = menu.addAction("Copy")
            action = menu.exec_(self.list_widget.mapToGlobal(pos))
            if action == copy_action:
                self.copy_to_clipboard(selected_item)

    def remove_history_item(self, item):
        self.clipboard_history.remove(item.text())
        self.show_alert("Item removed.")

    def save_to_file(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        file_path, _ = QFileDialog.getSaveFileName(self, "Save Clipboard History", "", "Text Files (*.txt);;All Files (*)", options=options)
        if file_path:
            if not file_path.endswith(".txt"):  
                file_path += ".txt"
            
            if not file_path:  
                file_path = expanduser("~") + "/Desktop/clipboard.txt"
            
            with open(file_path, "w") as file:
                for item_text in self.clipboard_history:
                    file.write(item_text + "\n")
            self.show_alert("Clipboard history saved to file.")

    def update_list_item_style(self, item, selected):
        if selected:
            item.setBackground(Qt.black)
            item.setForeground(Qt.red)
        else:
            item.setBackground(Qt.white)
            item.setForeground(Qt.black)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon("icon.ico"))
    window = ClipboardManagerApp()

    timer = QTimer()
    timer.timeout.connect(window.update_clipboard_content)
    timer.start(1000)

    window.show()

    sys.exit(app.exec_())